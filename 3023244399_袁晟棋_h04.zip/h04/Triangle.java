
package com.huawei.classroom.student.h04;

public class Triangle{
    private double A;
    private double B;
    private double C;
    public void setA(double A){
        this.A = A;
    }
    public void setB(double B){
        this.B = B;
    }
    public void setC(double C){
        this.C = C;
    }
    public double getArea(){
        double rho = (A + B + C) / 2;
        double ans = rho * (rho - A) * (rho - B) * (rho - C);
        return Math.sqrt(ans);
    }
}