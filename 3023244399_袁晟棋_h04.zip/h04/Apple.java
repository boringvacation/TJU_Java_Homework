/**
 * 
 */
package com.huawei.classroom.student.h04;

/**
 * 
 * 根据本类的要求，构建类并设置合适的方法和属性
 * 
 * @author Administrator
 *
 */
public class Apple{
	String color;
	int size;
	Apple(){
		color = "red";
		size = 23;
	}
	Apple(int size, String color){
		this.size = size;
		this.color = color;
	}
	public String getColor(){
		return color;
	}
	public int getSize(){
		return size;
	}
}


