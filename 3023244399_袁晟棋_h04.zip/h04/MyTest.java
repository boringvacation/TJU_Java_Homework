package com.huawei.classroom.student.h04;


public class MyTest {

    public void test() {
    	System.out.println("called");
        testApple();
        testTriangle();
        testStack();
    }

    private void testApple() {
        // 测试Apple默认构造函数
    	System.out.println("called");
        Apple app1 = new Apple();
        if (!app1.getColor().equals("red")) {
            System.out.println("Apple默认构造测试失败");
        }

        // 测试Apple带参数构造函数
        int size = 10;
        String color = "yellow";
        Apple app2 = new Apple(size, color);
        if (!app2.getColor().equals(color) || app2.getSize() != size) {
            System.out.println("Apple参数构造测试失败");
        }
    }

    private void testTriangle() {
        // 测试三角形面积计算
        Triangle tr = new Triangle();
        tr.setA(3);
        tr.setB(4);
        tr.setC(5);
        double area = tr.getArea();
        if (Math.abs(area - 6) >= 0.001) {
            System.out.println("三角形面积计算测试失败");
        }
    }

    private void testStack() {
        // 测试栈的基本操作
        MyStack stack = new MyStack(3);
        if (!stack.isEmpty()) {
            System.out.println("栈初始状态测试失败");
        }

        stack.push(1);
        stack.push(4);
        stack.push(5);

        if (!stack.isFull()) {
            System.out.println("栈填满状态测试失败");
        }

        if (stack.pop() != 5) {
            System.out.println("栈弹出元素测试失败");
        }

        if (stack.isFull()) {
            System.out.println("栈弹出后状态测试失败");
        }
        
        // 测试边界情况
        try {
            stack.push(6);
            stack.push(7); // 应该触发栈满异常
            System.out.println("栈溢出未正确处理");
        } catch (Exception e) {
            // 预期中的异常
        }
    }
}
