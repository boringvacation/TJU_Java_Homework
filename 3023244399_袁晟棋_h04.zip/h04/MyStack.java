
package com.huawei.classroom.student.h04;

public class MyStack{
    int size;
    int curSize;
    int[] arr;
    MyStack(int size){
        this.size = size;
        arr = new int[size];
        curSize = 0;
    }
    public int pop(){
        if(!isEmpty()){
            curSize--;
            return arr[curSize];
        }
        return -1;
    }
    public void push(int e){
        if(!isFull()){
            arr[curSize] = e;
            curSize++;
        }
    }
    public boolean isEmpty(){
        if(curSize == 0){
            return true;
        }
        return false;
    }
    public boolean isFull(){
        if(curSize == size){
            return true;
        }
        return false;
    }
}

