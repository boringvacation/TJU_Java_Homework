
package com.huawei.classroom.student.h02;

public class TestHome02 {
    public static void test(){
        testCalcArea();
        testGetSum();
        testIsTriangle();
        testIsEq();
        testGetGrade();
        testIsPrime();
        testGetEvenSum();
        testGetMax();
    }

    // 测试 calcArea 函数
    public static void testCalcArea() {
        if (calcArea(5) == 78.5f) System.out.println("calcArea测试点1 正确");
        if (calcArea(0) == 0) System.out.println("calcArea测试点2 正确");
        if (calcArea(10) == 314.0f) System.out.println("calcArea测试点3 正确");
    }

    // 测试 getSum 函数
    public static void testGetSum() {
        if (getSum(1, 3) == 6) System.out.println("getSum测试点1 正确");
        if (getSum(5, 5) == 5) System.out.println("getSum测试点2 正确");
        if (getSum(3, 1) == 0) System.out.println("getSum测试点3 正确");
    }

    // 测试 isTriangle 函数
    public static void testIsTriangle() {
        if (isTriangle(3, 4, 5)) System.out.println("isTriangle测试点1 正确");
        if (!isTriangle(1, 2, 3)) System.out.println("isTriangle测试点2 正确");
        if (!isTriangle(0, 1, 2)) System.out.println("isTriangle测试点3 正确");
    }

    // 测试 isEq 函数
    public static void testIsEq() {
        if (isEq(1.0f, 1.00009f)) System.out.println("isEq测试点1 正确");
        if (!isEq(1.0f, 1.0002f)) System.out.println("isEq测试点2 正确");
        if (!isEq(1.0f, -1.0f)) System.out.println("isEq测试点3 正确");
    }

    // 测试 getGrade 函数
    public static void testGetGrade() {
        if (getGrade(90) == 'A') System.out.println("getGrade测试点1 正确");
        if (getGrade(89) == 'B') System.out.println("getGrade测试点2 正确");
        if (getGrade(101) == 'E') System.out.println("getGrade测试点3 正确");
    }

    // 测试 isPrime 函数
    public static void testIsPrime() {
        if (isPrime(2) && isPrime(13)) System.out.println("isPrime测试点1 正确");
        if (!isPrime(4) && !isPrime(9)) System.out.println("isPrime测试点2 正确");
        if (!isPrime(0) && !isPrime(1)) System.out.println("isPrime测试点3 正确");
    }

    // 测试 getEvenSum 函数
    public static void testGetEvenSum() {
        if (getEvenSum(2, 5) == 6) System.out.println("getEvenSum测试点1 正确");
        if (getEvenSum(5, 2) == 0) System.out.println("getEvenSum测试点2 正确");
        if (getEvenSum(4, 8) == 18) System.out.println("getEvenSum测试点3 正确");
    }

    // 测试 getMax 函数
    public static void testGetMax() {
        if (getMax(3, 5, 2) == 5) System.out.println("getMax测试点1 正确");
        if (getMax(-1, -2, -3) == -1) System.out.println("getMax测试点2 正确");
        if (getMax(4, 4, 4) == 4) System.out.println("getMax测试点3 正确");
    }

    // 以下是被测试的函数
    public static float calcArea(float radius) {
        float pi = 3.14f;
        return pi * radius * radius;
    }

    public static int getSum(int a, int b) {
        int sum = 0;
        for (int i = a; i <= b; i++) {
            sum += i;
        }
        return sum;
    }

    public static boolean isTriangle(int a, int b, int c) {
        return helper(a, b, c) && helper(b, a, c) && helper(c, a, b);
    }

    public static boolean helper(int a, int b, int c) {
        return a < b + c;
    }

    public static boolean isEq(float f1, float f2) {
        return Math.abs((double) f1 - (double) f2) < 0.0001;
    }

    public static char getGrade(int score) {
        if (score >= 90) return 'A';
        else if (score >= 80) return 'B';
        else if (score >= 70) return 'C';
        else if (score >= 60) return 'D';
        else return 'E';
    }

    public static boolean isPrime(int i) {
        if (i == 0 || i == 1) return false;
        else if (i == 2) return true;
        for (int a = 2; a < i; a++) {
            if (i % a == 0) return false;
        }
        return true;
    }

    public static int getEvenSum(int i, int j) {
        int sum = 0;
        for (int a = i; a <= j; a++) {
            if (isEven(a)) sum += a;
        }
        return sum;
    }

    public static boolean isEven(int a) {
        return a % 2 == 0;
    }

    public static int getMax(int i, int j, int k) {
        return greater(greater(i, j), greater(j, k));
    }

    public static int greater(int a, int b) {
        return a > b ? a : b;
    }
}