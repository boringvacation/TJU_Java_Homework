package com.huawei.classroom.student.h08;

public class LoginUtil {
	public void login(String userName, String key) {
		if(userName.equals("a") && key.equals("a")) {
			
		}else {
			throw new InvalidUserException();
		}
	}
}