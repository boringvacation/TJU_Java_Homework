package com.huawei.classroom.student.h08;

public class Dog {
	int eatCnt;
	Dog(){
		eatCnt = 0;
	}
	public void feed() {
		eatCnt++;
		if(eatCnt > 3) {
			throw new CantEatMoreException("I can not eat more!");
		}
	}
}
