package com.huawei.classroom.student.h08;

public class Bank {
	int money;
	Bank(){
		money = 0;
	}
	public void save(int s) {
		money += s;
	}
	public void get(int g) {
		if(g <= money) {
			money -= g;
		}else {
			throw new NoMoneyException();
		}
	}
}
