package com.huawei.classroom.student.h08;

public class TypeValidator {
	public void validate(Object param) {
		if(!(param instanceof String)) {
			throw new InputException();
		}
	}
}
