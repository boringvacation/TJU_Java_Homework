package com.huawei.classroom.student.h08;

public class InvalidUserException extends RuntimeException {
	
}
