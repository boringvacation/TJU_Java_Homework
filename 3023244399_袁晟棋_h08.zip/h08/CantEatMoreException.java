package com.huawei.classroom.student.h08;

public class CantEatMoreException extends RuntimeException{
	CantEatMoreException(String message){
		super(message);
	}
}
