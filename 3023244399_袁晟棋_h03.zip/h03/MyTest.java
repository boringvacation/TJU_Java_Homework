
package com.huawei.classroom.student.h03;

public class MyTest {
    public static void testAll() {
        testIsNarcissisticNum();
        testPerfectnumber();
        testFactorial();
        testBinToDec();
        testGetRoot();
        testGetPascalTriangle();
        testZipSpace();
    }

    private static void testIsNarcissisticNum() {
        // 函数1测试
        if (Home03.isNarcissisticNum(153)) {
            System.out.println("函数1测试点1 正确");
        } else {
            System.out.println("函数1测试点1 错误");
        }

        if (Home03.isNarcissisticNum(370)) {
            System.out.println("函数1测试点2 正确");
        } else {
            System.out.println("函数1测试点2 错误");
        }

        if (!Home03.isNarcissisticNum(123)) {
            System.out.println("函数1测试点3 正确");
        } else {
            System.out.println("函数1测试点3 错误");
        }
    }

    private static void testPerfectnumber() {
        // 函数2测试
        if (Home03.Perfectnumber(6)) {
            System.out.println("函数2测试点1 正确");
        } else {
            System.out.println("函数2测试点1 错误");
        }

        if (Home03.Perfectnumber(28)) {
            System.out.println("函数2测试点2 正确");
        } else {
            System.out.println("函数2测试点2 错误");
        }

        if (!Home03.Perfectnumber(7)) {
            System.out.println("函数2测试点3 正确");
        } else {
            System.out.println("函数2测试点3 错误");
        }
    }

    private static void testFactorial() {
        // 函数3测试
        if (Home03.factorial(0) == 0) { // 注意原代码可能有bug
            System.out.println("函数3测试点1 正确");
        } else {
            System.out.println("函数3测试点1 错误");
        }

        if (Home03.factorial(5) == 120) {
            System.out.println("函数3测试点2 正确");
        } else {
            System.out.println("函数3测试点2 错误");
        }

        if (Home03.factorial(1) == 1) {
            System.out.println("函数3测试点3 正确");
        } else {
            System.out.println("函数3测试点3 错误");
        }
    }

    private static void testBinToDec() {
        // 函数4测试
        if (Home03.binToDec("1000").equals("8")) {
            System.out.println("函数4测试点1 正确");
        } else {
            System.out.println("函数4测试点1 错误");
        }

        if (Home03.binToDec("10000").equals("16")) {
            System.out.println("函数4测试点2 正确");
        } else {
            System.out.println("函数4测试点2 错误");
        }

        if (Home03.binToDec("0101").equals("5")) {
            System.out.println("函数4测试点3 正确");
        } else {
            System.out.println("函数4测试点3 错误");
        }
    }

    private static boolean compareDoubleArray(double[] a, double[] b) {
        if (a == null || b == null) return false;
        if (a.length != b.length) return false;
        for (int i = 0; i < a.length; i++) {
            if (Math.abs(a[i] - b[i]) > 0.001) return false;
        }
        return true;
    }

    private static void testGetRoot() {
        // 函数5测试
        double[] result1 = Home03.getRoot(1, -2, 1);
        if (compareDoubleArray(result1, new double[]{1, 1})) {
            System.out.println("函数5测试点1 正确");
        } else {
            System.out.println("函数5测试点1 错误");
        }

        if (Home03.getRoot(1, -2, 2) == null) {
            System.out.println("函数5测试点2 正确");
        } else {
            System.out.println("函数5测试点2 错误");
        }

        double[] result3 = Home03.getRoot(1, 0, -4);
        if (compareDoubleArray(result3, new double[]{2, -2})) {
            System.out.println("函数5测试点3 正确");
        } else {
            System.out.println("函数5测试点3 错误");
        }
    }

    private static boolean compareIntArray(int[] a, int[] b) {
        if (a == null || b == null) return false;
        if (a.length != b.length) return false;
        for (int i = 0; i < a.length; i++) {
            if (a[i] != b[i]) return false;
        }
        return true;
    }

    private static void testGetPascalTriangle() {
        // 函数6测试
        if (compareIntArray(Home03.getPascalTriangle(4), new int[]{1, 3, 3, 1})) {
            System.out.println("函数6测试点1 正确");
        } else {
            System.out.println("函数6测试点1 错误");
        }

        if (compareIntArray(Home03.getPascalTriangle(6), new int[]{1, 5, 10, 10, 5, 1})) {
            System.out.println("函数6测试点2 正确");
        } else {
            System.out.println("函数6测试点2 错误");
        }

        if (compareIntArray(Home03.getPascalTriangle(1), new int[]{1})) {
            System.out.println("函数6测试点3 正确");
        } else {
            System.out.println("函数6测试点3 错误");
        }
    }

    private static void testZipSpace() {
        // 函数7测试
        if ("abc".equals(Home03.zipSpace(" a b  c "))) {
            System.out.println("函数7测试点1 正确");
        } else {
            System.out.println("函数7测试点1 错误");
        }

        if ("hello".equals(Home03.zipSpace("hello"))) {
            System.out.println("函数7测试点2 正确");
        } else {
            System.out.println("函数7测试点2 错误");
        }

        if ("".equals(Home03.zipSpace("   "))) {
            System.out.println("函数7测试点3 正确");
        } else {
            System.out.println("函数7测试点3 错误");
        }
    }
}