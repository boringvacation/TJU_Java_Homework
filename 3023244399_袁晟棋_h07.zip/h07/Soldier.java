package com.huawei.classroom.student.h07;

public abstract class Soldier extends GameObject {

	public static int livingSoldierCount = 0;
	public static int deadedSoldierCount = 0;

	Soldier() {
		 livingSoldierCount++;
		// TODO Auto-generated constructor stub
	}
	Soldier(int health, int strength, int range) {
		livingSoldierCount++;
		// TODO Auto-generated constructor stub
	}

	public static int getLivingSoldierCount() {
		return livingSoldierCount;
	}

	public static int getDeadedSoldierCount() {
		return deadedSoldierCount;
	}
	public void dead() {
		super.dead();
		livingSoldierCount--;
		deadedSoldierCount++;
	}
	public void attack(GameObject obj) {
		int dx = this.getX() - obj.getX();
		int dy = this.getY() - obj.getY();
		double dis = Math.pow(dx * dx + dy * dy, 0.5);
		if (this.getRange() < dis) {
			return;
		}
		if (obj instanceof Dog) {
			obj.changeHealth(1000);;
		} else {
			obj.setHealth(obj.getHealth() - this.getStrength());
		}
	}
	
}
