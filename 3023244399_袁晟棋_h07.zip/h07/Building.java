package com.huawei.classroom.student.h07;

public class Building extends GameObject {
	public Building() {
		
	}
	public Building( int x ,int y) {
		 Building();
		 this.setX(x);
		 this.setY(y);
	}
}
