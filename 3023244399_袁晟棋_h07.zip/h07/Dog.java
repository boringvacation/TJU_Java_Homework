package com.huawei.classroom.student.h07;

public class Dog extends GameObject {

	public Dog() {
		super();
		// super( Param.DOG_HEALTH,Param.DOG_STRENGTH);
		// TODO Auto-generated constructor stub
	}

	public void attack(GameObject target) {
		if(target.isAlive == false) {
			return;
		}
		int dx = this.getX() - target.getX();
		int dy = this.getY() - target.getY();
		double dis = Math.pow(dx * dx + dy * dy, 0.5);
		if (this.getRange() <= dis) {
			return;
		}
		if (target instanceof Soldier) {
			target.dead();
		} else {
			target.setHealth(target.getHealth() - this.getStrength());
		}
	}

}
