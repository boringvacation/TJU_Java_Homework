package com.huawei.classroom.student.h06;

public class Tank extends GameObject{
	Tank(){
		
	}
	public void tankInit(int health, int attackPower) {
		setHealth(health);
		setAttackPower(attackPower);
		this.isAlive = true;
		this.attackRange = 10;
	}
}