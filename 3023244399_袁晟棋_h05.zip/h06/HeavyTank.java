package com.huawei.classroom.student.h06;

public class HeavyTank extends Tank{
	HeavyTank(){
		tankInit(200, 20);
	}
	HeavyTank(int x, int y){
		this();
		setXY(x,y);
	}
}

