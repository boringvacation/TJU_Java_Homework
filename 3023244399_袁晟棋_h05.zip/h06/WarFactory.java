package com.huawei.classroom.student.h06;

public class WarFactory extends Building{
	WarFactory(){
		setHealth(100);
		this.isAlive = true;
	}
	WarFactory(int x, int y){
		this();
		setXY(x, y);
	}
	public Object building(EnumObjectType t) {
		if(t == EnumObjectType.mediumTank) {
			return new MediumTank(this.x, this.y);
		}else if(t == EnumObjectType.heavyTank) {
			return new HeavyTank(this.x, this.y);
		}
		return null;
	}
}
