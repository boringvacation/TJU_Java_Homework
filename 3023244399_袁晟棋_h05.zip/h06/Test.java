package com.huawei.classroom.student.h06;

public class Test {

	public Test() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//某一款游戏，其主要角色如下:
		//游戏中每个对象有当前 x,y坐标，坐标值 取值范围为整数。
		//非建筑物可以通过move(dx,dy)来移动坐标值,dx,dy表示x轴,y轴增量, 取值范围为整数。
		//对象A攻击B的时候，要满足两个对象之间直线距离小于等于A的攻击范围,否则攻击无效（被攻击方不减健康值）
		//任何对象有getHealth() 方法，返回当前生命值，如果已经死亡则返回 <=0的一个数字
		//任何对象有isDestroyed() 方法，如果生命值<=0则true,否则false
		
		//GameBase 玩家基地 初始生命值500，无攻击力，初始x,y值在创建时指定
		//HeavyTank 重型坦克 初始生命值200，攻击力 20,攻击范围10,初始x,y值就是兵工厂的x,y 
		//Medium Tank  轻型坦克  初始生命值100，攻击力 10，攻击范围10,初始x,y值就是兵工厂的x,y 
		//War Factroy 兵工厂   初始生命值100，无攻击力  ，初始x,y值在创建时指定
		//Barrack 兵营，可以训练出步枪兵、 RPG兵、军犬,初始生命值100，无攻击力，初始x,y值在创建时指定
		//Rifle soldier 步枪兵  初始生命值50(对战 军犬除外)，攻击力 5（对战军犬可以一次击毙军犬)，攻击范围5,初始x,y值就是兵营的x,y 
		//Rocket soldier 火箭兵  初始生命值50(对战 军犬除外)，攻击力 10 ，攻击范围10，初始x,y值就是兵营的x,y 
		//Dog 军犬 ,初始生命值50，攻击力5(对战人类时候一口毙命)，攻击范围5，初始x,y值就是兵营的x,y 
		//此外还要能通过Soldier.getLivingSoldierCount/getDeadedSoldierCount 统计现在有多少个活着的和死去的士兵数量
		
		//请遵循以上游戏规则，并根据如下测试代码设计代码
		//作业批改的时候，方法可能不同组合 
		//例如让一个物体移动,超出或者进入攻击范围，判断是否攻击有效
		//让一个物体制造出来以后，不移动，然后另一个物体攻击，判断该物体是否使用了默认的x,y
		
		//未来可能分玩家，例如玩家A，玩家B，玩家C
		//未来可能玩家A战斗单元不能攻击自己的战斗单元
		//未来玩家之间可能要结盟、取消结盟
		//未来坦克攻击以后，造成的杀伤可能不是点杀伤，而是一个杀伤范围
		//....
		Testh05.testh05();
		test2();
		
		GameBase gameBase = GameBase.createGameBase(10,10);
		if(gameBase.getHealth()==500) {
		System.out.println("ok1"); 
		}
		Barrack barrack=(Barrack)gameBase.building(EnumObjectType.barrack, 20, 20) ;
		if(barrack.getHealth()==100) {
			System.out.println("ok2"); 
		}
		//traing 训练出新的士兵或者狗
		RifleSoldier rifleSoldier1=(RifleSoldier)barrack.traing(EnumObjectType.rifleSoldier);
		if(rifleSoldier1.getHealth()==50) {
			System.out.println("ok3"); 
		}
		RPGSoldier rPGSoldier1=(RPGSoldier)barrack.traing(EnumObjectType.RPGSoldier );
		if(rPGSoldier1.getHealth()==50) {
			System.out.println("ok4"); 
		}
		Dog dog1=(Dog)barrack.traing(EnumObjectType.dog );
		if(dog1.getHealth()==50) {
			System.out.println("ok5"); 
		}
		//构造新的兵工厂
		WarFactory warFactory=(WarFactory)gameBase.building(EnumObjectType.warFactory, 30, 30) ;
		if(warFactory.getHealth()==100) {
			System.out.println("ok6"); 
		}
		//building 建造各自型号坦克
		Tank mediumTank1=(MediumTank)warFactory.building(EnumObjectType.mediumTank);
		if(mediumTank1.getHealth()==100) {
			System.out.println("ok7"); 
		}
		
		Tank heavyTank1=(HeavyTank)warFactory.building(EnumObjectType.heavyTank );
		if(heavyTank1.getHealth()==200) {
			System.out.println("ok8"); 
		}
		
		//移动的是坐标值增量
		heavyTank1.move(10, 10);
		rifleSoldier1.move(5, 5);
		dog1.move(0, 0); 
		mediumTank1.attack(heavyTank1);
		 
		//攻击无效，距离太远，health
		if(heavyTank1.getHealth()==200){
			System.out.println("ok9"); 
		}
		
		mediumTank1.attack(rifleSoldier1); 
		if(rifleSoldier1.getHealth()==40 ) {
			System.out.println("ok10");
		}
		if( Soldier.getLivingSoldierCount()==2 ) {
			System.out.println("ok11");
		}
	}//fun
	public static void test2() {
	    // 初始化玩家基地和基础单位
	    GameBase gameBase = GameBase.createGameBase(10, 10);
	    Barrack barrack = (Barrack) gameBase.building(EnumObjectType.barrack, 20, 20);
	    WarFactory factory = (WarFactory) gameBase.building(EnumObjectType.warFactory, 30, 30);

	    // 测试点1-8: 基础单位初始属性
	    test(gameBase.getHealth() == 500, "ok1");   // 基地生命值
	    test(barrack.getHealth() == 100, "ok2");    // 兵营生命值
	    RifleSoldier rifle1 = (RifleSoldier) barrack.traing(EnumObjectType.rifleSoldier);
	    test(rifle1.getHealth() == 50, "ok3");      // 步枪兵生命值
	    RPGSoldier rpg1 = (RPGSoldier) barrack.traing(EnumObjectType.RPGSoldier);
	    test(rpg1.getHealth() == 50, "ok4");         // 火箭兵生命值
	    Dog dog1 = (Dog) barrack.traing(EnumObjectType.dog);
	    test(dog1.getHealth() == 50, "ok5");         // 军犬生命值
	    test(factory.getHealth() == 100, "ok6");     // 兵工厂生命值
	    Tank mediumTank = (MediumTank) factory.building(EnumObjectType.mediumTank);
	    test(mediumTank.getHealth() == 100, "ok7");  // 轻型坦克生命值
	    Tank heavyTank = (HeavyTank) factory.building(EnumObjectType.heavyTank);
	    test(heavyTank.getHealth() == 200, "ok8");   // 重型坦克生命值

	    // 测试点9-12: 移动和默认坐标
	    test(mediumTank.x == 30 && mediumTank.y == 30, "ok9");  // 坦克初始坐标在兵工厂
	    rifle1.move(5, 5);
	    test(rifle1.x == 25 && rifle1.y == 25, "ok10");          // 步枪兵移动后坐标
	    dog1.move(0, 0);
	    test(dog1.x == 20 && dog1.y == 20, "ok11");              // 军犬移动后坐标
	    test(barrack.x == 20 && barrack.y == 20, "ok12");        // 兵营无法移动

	    // 测试点13-16: 攻击范围和伤害计算
	    mediumTank.attack(heavyTank); 
	    
	    test(heavyTank.getHealth() == 200, "ok13");  // 攻击距离超出（默认距离10，移动后超出）
	    rifle1.move(0,0); // 移动步枪兵到 (25,25) -> (0,0)
	    mediumTank.attack(rifle1);
	    test(rifle1.getHealth() == 40, "ok14");      // 轻型坦克攻击伤害10
	    rpg1.attack(mediumTank);
	    test(mediumTank.getHealth() == 90, "ok15");  // 火箭兵攻击伤害10
	    test(Soldier.getLivingSoldierCount() == 2, "ok16"); // 存活士兵：rifle1(40), rpg1(50)

	    // 测试点17-20: 特殊攻击规则
	    dog1.attack(rifle1);
	    test(rifle1.isDestroyed(), "ok17");          // 军犬对士兵一击必杀
	    RifleSoldier rifle2 = (RifleSoldier) barrack.traing(EnumObjectType.rifleSoldier);
	    rifle2.attack(dog1);
	    test(dog1.isDestroyed(), "ok18");            // 步枪兵对军犬一击必杀
	    test(Soldier.getLivingSoldierCount() == 1, "ok19"); // 存活士兵：rpg1(50)
	    test(Soldier.getDeadedSoldierCount() == 2, "ok20"); // 死亡士兵：rifle1, rifle2

	    // 测试点21+: 扩展场景（可根据需要继续添加）
	    // 例如：火箭兵攻击范围验证、重型坦克攻击力验证等
	}

	// 通用测试方法
	private static void test(boolean condition, String msg) {
	    if (condition) {
	        System.out.println(msg);
	    }
	}

}
