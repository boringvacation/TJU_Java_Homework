package com.huawei.classroom.student.h06;

public enum EnumObjectType{
	rifleSoldier,
	RPGSoldier,
	dog,
	mediumTank,
	heavyTank,
	barrack,
	warFactory
}
