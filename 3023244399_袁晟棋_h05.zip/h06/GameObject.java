package com.huawei.classroom.student.h06;

public class GameObject {
	private int health;
	private int attackPower;
	public boolean isAlive;
	public int x;
	public int y;
	public int attackRange;
	//方法
	public int getHealth() {
		if(this.isAlive) {
			return this.health;
		}
		return -1;
	}
	public void setHealth(int health) {
		this.health = health;
	}
	public int getAttackPower() {
		return this.attackPower;
	}
	public void setAttackPower(int attackPower) {
		this.attackPower = attackPower;
	}
	public boolean isDestroyed() {
		return !this.isAlive;
	}
	public void setXY(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	public void attack(GameObject target) {
		if(target.isAlive && calDis(this.x, this.y, target.x, target.y) <= this.attackRange) {
			target.health -= this.attackPower;
			if(target.health <= 0) {
				target.die();
			}
		}	
	}
	public void die() {
		this.isAlive = false;
		this.setHealth(0);
	}
	public void move(int disX, int disY) {
		this.x += disX;
		this.y += disY;
	}
	public double calDis(int xa, int ya, int xb, int yb) {
	    double deltaX = xb - xa;
	    double deltaY = yb - ya;

	    return Math.sqrt(deltaX * deltaX + deltaY * deltaY);
	}
}
