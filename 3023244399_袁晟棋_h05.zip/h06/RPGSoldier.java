package com.huawei.classroom.student.h06;

public class RPGSoldier extends Soldier{
	RPGSoldier(){
		soldierInit(50, 10);
	}
	RPGSoldier(int x, int y){
		this();
		this.attackRange = 10;
		setXY(x, y);
	}
}

