package com.huawei.classroom.student.h06;

public class Soldier extends GameObject{
	public static int cntAlive = 0;
	public static int cntDead = 0;
	
	public void soldierInit(int health, int attackPower) {
		setHealth(health);
		setAttackPower(attackPower);
		this.isAlive = true;
		cntAlive++;
	}
	public void die() {
		this.isAlive = false;
		this.setHealth(0);
		cntAlive--;
		cntDead++;
	}
	public static int getLivingSoldierCount() {
		return cntAlive;
	}
	public static int getDeadedSoldierCount() {
		return cntDead;
	}
	public void attack(GameObject target) {
		if(target.isAlive && calDis(this.x, this.y, target.x, target.y) <= this.attackRange) {
			if(target instanceof Dog) {
				target.die();
			}else {
				target.setHealth(target.getHealth() - this.getAttackPower());
				if(target.getHealth() <= 0) {
					target.die();
				}
			}
		}
	}//fun
}

