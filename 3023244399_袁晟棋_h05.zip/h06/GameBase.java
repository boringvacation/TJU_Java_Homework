package com.huawei.classroom.student.h06;

public class GameBase extends Building{
	GameBase(int x, int y){
		setHealth(500);
		setAttackPower(0);
		this.x = x;
		this.y = y;
		this.isAlive = true;
	}
	public static GameBase createGameBase(int x, int y) {
		return new GameBase(x, y);
	}
	public Object building(EnumObjectType t, int x, int y) {
		if(t == EnumObjectType.barrack) {
			return new Barrack(x, y);
		}else if(t == EnumObjectType.warFactory) {
			return new WarFactory(x, y);
		}
		return null;
	}
	
}
