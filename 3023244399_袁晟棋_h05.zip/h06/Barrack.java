package com.huawei.classroom.student.h06;

public class Barrack extends Building{
	Barrack(){
		setHealth(100);
		this.isAlive = true;
	}
	Barrack(int x, int y){
		//这里有点好像没学过
		this();
		setXY(x,y);
	}
	public Object traing(EnumObjectType t) {
		if(t == EnumObjectType.rifleSoldier) {
			return new RifleSoldier(this.x, this.y);
		}else if(t == EnumObjectType.RPGSoldier) {
			return new RPGSoldier(this.x, this.y);
		}else if(t == EnumObjectType.dog) {
			return new Dog(this.x, this.y);
		}
		return null;
	}
}
