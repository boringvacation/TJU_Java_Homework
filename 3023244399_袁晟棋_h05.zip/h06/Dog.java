package com.huawei.classroom.student.h06;

public class Dog extends GameObject {
	Dog(){
		setHealth(50);
		setAttackPower(5);
		this.isAlive = true;
		this.attackRange = 5;
	}
	Dog(int x, int y){
		this();
		setXY(x, y);
	}
	public void attack(GameObject target) {
		if(target.isAlive && calDis(this.x, this.y, target.x, target.y) <= this.attackRange) {
			if(target instanceof RifleSoldier || target instanceof RPGSoldier) {
				target.die();
			}else {
				target.setHealth(target.getHealth() - this.getAttackPower());
				if(target.getHealth() <= 0) {
					target.die();
				}
			}
		}
	}//fun
}
