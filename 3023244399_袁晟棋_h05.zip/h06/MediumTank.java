package com.huawei.classroom.student.h06;

public class MediumTank extends Tank{
	MediumTank(){
		tankInit(100, 10);
	}
	MediumTank(int x, int y){
		this();
		setXY(x,y);
	}
}

