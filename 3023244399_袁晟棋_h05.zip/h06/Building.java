package com.huawei.classroom.student.h06;

public class Building extends GameObject{
	public void move(int disX, int disY) {
		
	}
}
