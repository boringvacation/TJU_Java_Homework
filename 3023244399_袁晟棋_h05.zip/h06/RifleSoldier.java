package com.huawei.classroom.student.h06;

public class RifleSoldier extends Soldier{
	RifleSoldier(){
		soldierInit(50, 5);
	}
	RifleSoldier(int x, int y){
		this();
		this.attackRange = 5;
		setXY(x, y);
	}
}