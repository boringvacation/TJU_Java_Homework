package com.huawei.classroom.student.h05;

public class Dog extends GameObject {
	private int attackPower;
	Dog(){
		setHealth(50);
		setAttackPower(5);
		this.isAlive = true;
	}
	public void attack(GameObject target) {
		if(target.isAlive) {
			if(target instanceof RifleSoldier || target instanceof RPGSoldier) {
				target.die();
			}else {
				target.setHealth(target.getHealth() - this.getAttackPower());
				if(target.getHealth() <= 0) {
					target.die();
				}
			}
		}
	}//fun
}
