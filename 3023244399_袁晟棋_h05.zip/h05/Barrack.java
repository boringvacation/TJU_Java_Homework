package com.huawei.classroom.student.h05;

public class Barrack extends GameObject{
	Barrack(){
		setHealth(100);
		this.isAlive = true;
	}
	public Object traing(EnumObjectType t) {
		if(t == EnumObjectType.rifleSoldier) {
			return new RifleSoldier();
		}else if(t == EnumObjectType.RPGSoldier) {
			return new RPGSoldier();
		}else if(t == EnumObjectType.dog) {
			return new Dog();
		}
		return null;
	}
}
