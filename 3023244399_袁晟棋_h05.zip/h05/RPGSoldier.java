package com.huawei.classroom.student.h05;

public class RPGSoldier extends Soldier{
	RPGSoldier(){
		soldierInit(50, 10);
	}
}
