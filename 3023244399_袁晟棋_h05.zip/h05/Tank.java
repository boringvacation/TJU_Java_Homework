package com.huawei.classroom.student.h05;

public class Tank extends GameObject{
	Tank(){
		
	}
	public void tankInit(int health, int attackPower) {
		setHealth(health);
		setAttackPower(attackPower);
		this.isAlive = true;
	}
}
