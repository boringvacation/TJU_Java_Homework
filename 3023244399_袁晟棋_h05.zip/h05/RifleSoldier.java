package com.huawei.classroom.student.h05;

public class RifleSoldier extends Soldier{
	RifleSoldier(){
		soldierInit(50, 5);
	}
}
