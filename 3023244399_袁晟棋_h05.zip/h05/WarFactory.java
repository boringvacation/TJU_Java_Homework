package com.huawei.classroom.student.h05;

public class WarFactory extends GameObject{
	WarFactory(){
		setHealth(100);
		this.isAlive = true;
	}
	public Object building(EnumObjectType t) {
		if(t == EnumObjectType.mediumTank) {
			return new MediumTank();
		}else if(t == EnumObjectType.heavyTank) {
			return new HeavyTank();
		}
		return null;
	}
}
