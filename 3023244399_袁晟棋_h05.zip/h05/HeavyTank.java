package com.huawei.classroom.student.h05;

public class HeavyTank extends Tank{
	HeavyTank(){
		tankInit(200, 20);
	}
}
