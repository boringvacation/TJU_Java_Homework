package com.huawei.classroom.student.h05;

public class GameObject {
	private int health;
	private int attackPower;
	public boolean isAlive;

	public int getHealth() {
		return this.health;
	}
	public void setHealth(int health) {
		this.health = health;
	}
	public int getAttackPower() {
		return this.attackPower;
	}
	public void setAttackPower(int attackPower) {
		this.attackPower = attackPower;
	}
	public boolean isDestroyed() {
		return !this.isAlive;
	}
	public void attack(GameObject target) {
		if(target.isAlive) {
			target.health -= this.attackPower;
			if(target.health <= 0) {
				target.die();
			}
		}	
	}
	public void die() {
		this.isAlive = false;
		this.setHealth(0);
	}
}
