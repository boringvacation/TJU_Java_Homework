package com.huawei.classroom.student.h05;

public class MediumTank extends Tank{
	MediumTank(){
		tankInit(100, 10);
	}
}
