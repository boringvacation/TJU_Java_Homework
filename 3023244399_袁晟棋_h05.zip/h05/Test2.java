package com.huawei.classroom.student.h05;

public class Test2 {
	public static void test2() {
	    // 初始化建筑
	    Barrack barrack = new Barrack();
	    WarFactory factory = new WarFactory();
	    
	    // 测试点1-2：建筑初始生命值
	    test(barrack.getHealth() == 100, "ok1");
	    test(factory.getHealth() == 100, "ok2");

	    // 训练/建造单位
	    RifleSoldier rifle1 = (RifleSoldier)barrack.traing(EnumObjectType.rifleSoldier);
	    RPGSoldier rpg1 = (RPGSoldier)barrack.traing(EnumObjectType.RPGSoldier);
	    Dog dog1 = (Dog)barrack.traing(EnumObjectType.dog);
	    Tank heavyTank = (HeavyTank)factory.building(EnumObjectType.heavyTank);
	    Tank mediumTank = (MediumTank)factory.building(EnumObjectType.mediumTank);


	    // 测试点3-7：单位初始属性
	    test(rifle1.getHealth() == 50, "ok3");
	    test(rpg1.getHealth() == 50, "ok4"); 
	    test(dog1.getHealth() == 50, "ok5");
	    test(heavyTank.getHealth() == 200, "ok6");
	    test(mediumTank.getHealth() == 100, "ok7");

	    // 测试点8：轻型坦克攻击步枪兵
	    mediumTank.attack(rifle1);
	    test(rifle1.getHealth() == 40, "ok8");

	    // 测试点9：狗对士兵一击必杀
	    dog1.attack(rifle1);
	    test(rifle1.isDestroyed(), "ok9");

	    // 测试点10：士兵攻击军犬
	    rpg1.attack(dog1);
	    test(dog1.isDestroyed(), "ok10");

	    // 测试点11：统计功能
	    test(Soldier.getLivingSoldierCount() == 1, "ok11");
	    test(Soldier.getDeadedSoldierCount() == 1, "ok12");

	    // 测试点13：重型坦克攻击兵营
	    heavyTank.attack(barrack);
	    test(barrack.getHealth() == 80, "ok13"); // 200-20 * 1=80

	    // 测试点14：军犬攻击坦克
	    Dog dog2 = (Dog)barrack.traing(EnumObjectType.dog);
	    dog2.attack(heavyTank);
	    test(heavyTank.getHealth() == 195, "ok14"); // 普通攻击5点伤害

	    // 测试点15：火箭兵攻击坦克
	    rpg1.attack(heavyTank);
	    test(heavyTank.getHealth() == 185, "ok15"); // 10点伤害
	    
	    // 测试点16：坦克互相攻击
	    heavyTank.attack(mediumTank);
	    test(mediumTank.getHealth() == 80, "ok16"); // 200-20=80? 需要确认坦克攻击力
		
	    // 测试点17：士兵攻击士兵
	    RifleSoldier rifle2 = (RifleSoldier)barrack.traing(EnumObjectType.rifleSoldier);
	    rifle2.attack(rpg1);
	    test(rpg1.getHealth() == 45, "ok17"); // 5点伤害
	    // 测试点18：多次攻击致死
	    for(int i=0;i<9;i++) {
	        mediumTank.attack(barrack);
	    }
	    test(barrack.isDestroyed(), "ok18"); // 初始100-10 * 10=0
	    // 测试点19：死亡单位无法被攻击
	    int preHealth = rifle1.getHealth();
	    mediumTank.attack(rifle1);
	    test(rifle1.getHealth() == preHealth, "ok19");
	    // 测试点20：统计最终状态
	    test(Soldier.getLivingSoldierCount() == 2, "ok20"); // rifle2和rpg1存活
	}

	// 通用测试方法
	private static void test(boolean condition, String msg) {
	    if(condition) {
	        System.out.println(msg);
	    }
	}
}
