package com.huawei.classroom.student.h10;
import java.util.HashMap;
/**
 * 把你作业的代码写到这个类里面
 * 不可以修改类的名字、包名、和固有的几个方法名以及方法的可见性
 * 可以增加其他方法、属性、类
 * 可以引用jdk的类
 * 不要引用jdk1.8以外第三方的包
 * 
 * @author cjy
 *
 */
public class Home10 {
	public Home10() {
		
	} 
	/**
	 * 将一个字符串中字符按出现频率的高到低排序返回，如果两个字符出现的频率一样，则将最先出现的字符排在前面
	 * 例如：orderChar(“abcdefg”)返回 “abcdefg” 
	 * orderChar(“abcdefgg”)返回 “gabcdef”
	 * orderChar(“abcdefgge”)返回 “egabcdf”
	 * orderChar(“天津大学软件学院”)返回 “学天津大软件院”
	 * @param content
	 * @return
	 */
    public char getMaxChar(HashMap<Character, Integer> map, HashMap<Character, Integer> firstPos) {
    	int max = -1;
    	int curPos = 0;
    	char ans = 'f';
    	for(char key : map.keySet()) {
    		if(max < map.get(key)) {
    			max = map.get(key);
    			ans = key;
    			curPos = firstPos.get(key);
    		}else if(max == map.get(key)) {
    			if(firstPos.get(key) < curPos) {
    				max = map.get(key);
        			ans = key;
        			curPos = firstPos.get(key);
    			}
    		}
    	}
    	return ans;
    }
	public String orderChar(String content) {
		//获取频率
		HashMap<Character, Integer> map = new HashMap<>();
		HashMap<Character, Integer> firstPos = new HashMap<>();
		char mid = 'a';
		for(int i = 0; i < content.length(); i++) {
			//先储存位置
			if(firstPos.containsKey(content.charAt(i)) == false) {
				firstPos.put(content.charAt(i), i);
			}
			if(map.containsKey(content.charAt(i)) == false) {
				map.put(content.charAt(i),1);
			}else {
				mid = content.charAt(i);
				map.put(mid, map.get(mid) + 1);
			}
		}
		//sort
		char maxChar;
		String ans = "";
		while(map.isEmpty() == false) {
			maxChar = getMaxChar(map, firstPos);
			ans = ans + maxChar;
			map.remove(maxChar);
		}
		return ans;
	}
	
}
