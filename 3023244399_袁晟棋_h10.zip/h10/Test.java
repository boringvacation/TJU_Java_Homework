package com.huawei.classroom.student.h10;

public class Test {

    public Test() {
        // 默认构造方法
    }

    public static void main(String[] args) {
        Home10 home10 = new Home10();

        // 测试 1：示例 1（出现频率最高的字符排在前面）
        testCase(home10, "abcdefgg", "gabcdef", 1);

        // 测试 2：示例 2（频率相同按首次出现顺序）
        testCase(home10, "abcdefgge", "egabcdf", 2);

        // 测试 3：多个字符频率相同，按首次出现顺序排序
        testCase(home10, "aabbcc", "abc", 3);

        // 测试 4：所有字符频率为1，保持原顺序
        testCase(home10, "abcdef", "abcdef", 4);

        // 测试 5：所有字符相同
        testCase(home10, "aaaaa", "a", 5);

        // 测试 6：混合频率和首次出现顺序
        testCase(home10, "xxyyzz", "xyz", 6);

        // 测试 7：中文示例（按首次出现顺序）
        testCase(home10, "天津大学软件学院", "学天津大软件院", 7);
    }

    /**
     * 统一测试用例执行方法
     * @param home10   被测对象
     * @param input    输入字符串
     * @param expected 期望输出
     * @param caseId   用例编号
     */
    private static void testCase(Home10 home10, String input, String expected, int caseId) {
        String result = home10.orderChar(input);
        if (result.equals(expected)) {
            System.out.println("case " + caseId + " ok");
        } else {
            System.out.println("case " + caseId + " error! 输入: \"" + input + "\" 预期: \"" + expected + "\" 实际: \"" + result + "\"");
        }
    }
}