package com.huawei.classroom.student.h09;
import java.util.*; 
//import java.util.HashMap;

/**
 * 把你作业的代码写到这个类里面
 * 不可以修改类的名字、包名、和固有的几个方法名以及方法的可见性
 * 可以增加其他方法、属性、类
 * 可以引用jdk的类
 * 不要引用jdk1.8以外第三方的包
 * 
 * @author cjy
 *
 */
public class Home09 {
	public Home09() {
		// TODO Auto-generated constructor stub
	}
	/**
	 * 计算出一段文字中不重复的字符的个数，例如“天津市天津大学 ”不重复字符为5
	 * 提示：使用java.util.HashSet 
	 * 难度系数1星
	 * @param s
	 * @return
	 */
	public int getDistinctCharCount(String s) {
		HashSet<Character> set= new HashSet<>();
		for(int i = 0; i < s.length(); i++) {
			if(set.contains(s.charAt(i)) == false) {
				set.add(s.charAt(i));
			}
		}
		return set.size();
	}
	/**
	 * 返回一段文字中，出现频率最高的字符（不考虑并列第一的情况） 例如：getFrequentChar("好好学习") 返回'好'
	 * 例如：getFrequentChar("我是天津大学软件学院学生") 返回'学'
	 * 提示：使用一个长度为65535的数组，或者使用HashMap   
	 * 难度系数2星
	 * @param s
	 * @return
	 */
	public char getFrequentChar(String s) {
		HashMap<Character, Integer> map = new HashMap<>();
		for(int i = 0; i < s.length(); i++) {
			if(map.containsKey(s.charAt(i)) == false) {
				//如果不存在
				map.put(s.charAt(i),1);
			}
			else {
				map.put(s.charAt(i), map.get(s.charAt(i)) + 1);
			}
		}
		// 遍历数组 找到最大值
		int max = -1;
		char ans = 'a';
		for(char key : map.keySet()) {
			if(max < map.get(key)) {
				ans = key;
				max = map.get(key);
			}
		}
		return ans;
	}
	

	
	/**
	 * 返回一段文字中，出现频率最高的词（每个词由2个字符构成，任意两个相邻的字符称为一个词，例如“天津大学，你好”由“天津”“津大”“大学”“学，”“，你”“你好” 6个词构成)
	 * 不会出现频率最高并列的情况
	 * 提示：使用HashMap 
	 * 难度系数2星
	 * @param content
	 * @return
	 */
	public String getFrequentWord(String content){
		HashMap<String, Integer> map = new HashMap<>();
		String cur;
		for(int i = 0; i < content.length() - 1; i++) {
			cur = "";
			cur += content.charAt(i);
			cur += content.charAt(i+1);
			if(map.containsKey(cur)) {
				map.put(cur, map.get(cur) + 1);
			}else {
				map.put(cur, 1);
			}
		}
		// 再获取哈希表最大值对应的键
		int max = -1;
		String ans = "";
		for(String key : map.keySet()) {
			if(max < map.get(key)) {
				ans = key;
				max = map.get(key);
			}
		}
		return ans;
	}
	 
	 
	
	/**
	 * 把一个StringBufer中所有的空格去掉
	 * 提示：不能新建StringBuffer对象，必须在原来的基础上删掉原来字符串
	 * 难度系数1星
	 * @param buf
	 */
	public void zipStringBufer(StringBuffer buf) {
		 for(int i = 0; i < buf.length(); ) {
			 if(buf.charAt(i) == ' ') {
				 buf.deleteCharAt(i);
			 }
			 else {
				 i++;
			 }
		 }
	}

 
}

